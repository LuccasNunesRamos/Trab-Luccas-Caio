#include "Bolsominion.h"



Bolsominion::Bolsominion()
{
}


Bolsominion::~Bolsominion()
{
}

void Bolsominion::especial()
{
}

void Bolsominion::setX(int x)
{
	this->x = x;
}

void Bolsominion::setY(int y)
{
	this->y = y;
}

