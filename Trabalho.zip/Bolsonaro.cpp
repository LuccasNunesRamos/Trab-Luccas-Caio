#include "Bolsonaro.h"


Bolsonaro::Bolsonaro()
{
}

Bolsonaro::~Bolsonaro()
{
}

void Bolsonaro::especial()
{
}