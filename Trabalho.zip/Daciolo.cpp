#include "Daciolo.h"

Daciolo::Daciolo()
{
}


Daciolo::~Daciolo()
{
}


void Daciolo::setAudio(string nome)
{
	som.setAudio(nome);
}


void Daciolo::especial()
{
	
}


